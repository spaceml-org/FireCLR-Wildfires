import os
import numpy as np
from osgeo import gdal
import math
# funcs to process the raw image to the model-ready
def normalizaed_data(img):
    #min-max normalization of the image based on all images
    #four bands, for different min, max
    img_normalized=np.zeros(img.shape)
    # parameters to normalize the S2
    max = [18408, 18855, 23857, 22105]
    min = [0, 0, 0, 0]
    for i in range(4):
        img_normalized[i,:,:]=(img[i,:,:]-min[i])/(max[i]-min[i])
    
    return img_normalized.astype(np.float64)

def load_image(img_src,normalization=True):
    '''
    args:
    img_src - directory to the target image

    return:
    data_mtrx - a dictionary of two data matrices for pre and post fire; each of them is in 3 dimensions (band,rows,cols)
    meta_data - metadata includes: transformation, projection, numerber of rows, number of columns, number of bands
    band_dict - band dictionary includes the information of each band
    '''
    
    s2_name = os.path.basename(img_src)[:-4]
    loc_name = 'Mesa'
    print("Loading image: %s - %s" %(loc_name,s2_name))
    
    ds = gdal.Open(img_src)
    ds_arr = ds.ReadAsArray().astype(np.float32)
    
    if normalization:
        ds_arr = normalizaed_data(ds_arr)
    
    print("Loading image is done!")
    return ds_arr,s2_name,loc_name
  
def create_image_tile(img_src, out_dir, stride_size=32, tile_size = 32):
    '''
    args:
    img_src - a path to 3-dimensional data matrix read from a satellite image
    tile_size - the size of the tile in integer, the default size is 3*3
    stride_size - the size of the stride in integer, for the size of moving pixels for each tile
    output - True/False, whether output the data matrix, the default is False
    out_dir - output directory of the tiled image the default is None. If the ouput is True, the out_dir is required. Output data type should be acceptable for the numpy.save, npy is recommended.

    return:
    data_mtrx_tile - a data matrix of the image after tiling

    '''
    data_mtrx, fname, loc_name = load_image(img_src)

    bands, rows, cols = data_mtrx.shape

    print("Start tiling the image...")

    new_rows = math.floor(1+(rows-tile_size)/stride_size) #asking huiqi to check this one, need to be changed
    new_cols = math.floor(1+(cols-tile_size)/stride_size)

    print("The numbers of rows and columns after tiling are (%d, %d)"%(new_rows,new_cols))

    for i in range(new_rows):
        if i<10:
            str_new_rows = '000'+str(i)
        elif i<100:
            str_new_rows = '00'+str(i)
        elif i<1000:
            str_new_rows = '0'+str(i)
        else:
            str_new_rows = str(i)
        for j in range(new_cols):
            if j<10:
                str_new_cols = '000'+str(j)
            elif j<100:
                str_new_cols = '00'+str(j)
            elif j<1000:
                str_new_cols = '0'+str(j)
            else:
                str_new_cols = str(j)
            cropped_arr = data_mtrx[:,i*stride_size : (i*stride_size+tile_size), j*stride_size : (j*stride_size+tile_size)]
            #cropped_arr[cropped_arr==0.0]=np.nan
            if np.isnan(cropped_arr).sum() == 0:
                output_file = os.path.join(out_dir,loc_name+"_"+fname+"_"+str_new_rows+"_"+str_new_cols+".npy")
                np.save(output_file, cropped_arr)
            if i == 0 and j==0:
                print("After tiling, the size of data matrix becomes: ", cropped_arr.shape)
    del data_mtrx, cropped_arr